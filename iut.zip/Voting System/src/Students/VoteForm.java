package Students;

import Connections.ConnectionToDB;
import Forms.Login;
import java.awt.List;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
public class VoteForm extends javax.swing.JFrame {
Connection conn = null;
PreparedStatement pst = null;
ResultSet rs = null;
ArrayList<String> DLCList = new ArrayList<String>();
int updateDLCList[] = new int[5];
int index;
String itemSelected;
String selected;
DefaultListModel dlm = new DefaultListModel();
int  JavaVote , CppVote,PhysicsVote,AEVote,CalculusVote,LAVote;
int courseVote;
    public VoteForm() {
        initComponents();
        conn = ConnectionToDB.ConnectToDB();
        this.setExtendedState(this.getExtendedState() | JFrame.MAXIMIZED_BOTH);
        populateJava();
        populateCpp();
        populatePhysics();
        populateAE();
        populateCalculus();
        populateLA();
        populateDLC();
    }
    public void close(){
        WindowEvent we = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(we);
    }
    public void populateJava(){
        try{
     
            String sql = "SELECT lastname,firstname,mail FROM candidates_info WHERE position='Java'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                JavaCombo.addItem(rs.getString("lastname")+" "+rs.getString("firstname")+" "+rs.getString("mail"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateCpp(){
        try{
            String sql = "SELECT lastname,firstname,mail FROM candidates_info WHERE position='Cpp'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                CppCombo.addItem(rs.getString("lastname")+" "+rs.getString("firstname")+" "+rs.getString("mail"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populatePhysics(){
        try{
            String sql = "SELECT lastname,firstname,mail FROM candidates_info WHERE position='Physics'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                PhysicsCombo.addItem(rs.getString("lastname")+" "+rs.getString("firstname")+" "+rs.getString("mail"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateAE(){
        try{
            String sql = "SELECT lastname,firstname, mail FROM candidates_info WHERE position='AE'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                AECombo.addItem(rs.getString("lastname")+" "+rs.getString("firstname")+" "+rs.getString("mail"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateCalculus(){
        try{
             String sql = "SELECT lastname,firstname,mail FROM candidates_info WHERE position='Calculus'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                CalculusCombo.addItem(rs.getString("lastname")+" "+rs.getString("firstname")+" "+rs.getString("mail"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateLA(){
        try{
             String sql = "SELECT lastname,firstname,mail FROM candidates_info WHERE position='LA'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                LACombo.addItem(rs.getString("lastname")+" "+rs.getString("firstname")+" "+rs.getString("mail"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void populateDLC(){
        try{
            String sql = "SELECT lastname,firstname,mail FROM candidates_info WHERE position='DLC'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            while(rs.next()){
                DLCCombo.addItem(rs.getString("lastname")+" "+rs.getString("firstname")+" "+rs.getString("mail"));
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void selectVoteCountForJava(){
        try{
            String sql = "SELECT vote_count FROM candidates_info WHERE fullname='"+JavaCombo.getSelectedItem()+"' AND position='Java'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               JavaVote =Integer.parseInt(rs.getString("vote_count"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForCpp(){
         try{
            String sql = "SELECT vote_count FROM candidates_info WHERE fullname='"+CppCombo.getSelectedItem()+"' AND position='Cpp'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
               CppVote = Integer.parseInt(rs.getString("vote_count"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForPhysics(){
        try{
            String sql = "SELECT vote_count FROM candidates_info WHERE fullname='"+PhysicsCombo.getSelectedItem()+"' AND position='Physics'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
                PhysicsVote =Integer.parseInt(rs.getString("vote_count"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForAE(){
        try{
            String sql = "SELECT vote_count FROM candidates_info WHERE fullname='"+AECombo.getSelectedItem()+"' AND position='AE'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            	AEVote = Integer.parseInt(rs.getString("vote_count"))+ 1;
            	
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForCalculus(){
        try{
            String sql = "SELECT vote_count FROM candidates_info WHERE fullname='"+CalculusCombo.getSelectedItem()+"' AND position='Calculus'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            	CalculusVote = Integer.parseInt(rs.getString("vote_count"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForLA(){
        try{
            String sql = "SELECT vote_count FROM candidates_info WHERE fullname='"+LACombo.getSelectedItem()+"' AND position='LA'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
            	LAVote = Integer.parseInt(rs.getString("vote_count"))+ 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
     public void selectVoteCountForDLC(){
          for(int x=0;x<DLCList.size();x++){
                 try{
                    String sql = "SELECT vote_count FROM candidates_info WHERE fullname='"+DLCList.get(x)+"' AND position='DLC'";
                    pst = conn.prepareStatement(sql);
                    rs  = pst.executeQuery();
                    if(rs.next()){   
                    	updateDLCList[x] = Integer.parseInt(rs.getString("vote_count")) + 1;
                    }
                }catch(Exception e){
                    JOptionPane.showMessageDialog(null, e.getMessage());
                } 
        
          }  
       
    }
    public void updateForJava(){
        try{
            String sql = "UPDATE candidates_info SET vote_count='"+ JavaVote +"' WHERE fullname='"+JavaCombo.getSelectedItem()+"' AND position='Java'";
            pst = conn.prepareStatement(sql);
            pst.execute();
  
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void updateForCpp(){
    try{
            String sql = "UPDATE candidates_info SET vote_count='"+ CppVote +"' WHERE fullname='"+CppCombo.getSelectedItem()+"' AND position=Cpp'";
            pst = conn.prepareStatement(sql);
            pst.execute();
     
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void updateForPhysics(){
        try{
            String sql = "UPDATE candidates_info SET vote_count='"+ PhysicsVote +"' WHERE fullname='"+PhysicsCombo.getSelectedItem()+"' AND position='Physics'";
            pst = conn.prepareStatement(sql);
            pst.execute();
   
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void updateForAE(){
    try{
            String sql = "UPDATE candidates_info SET vote_count='"+ AEVote +"' WHERE fullname='"+AECombo.getSelectedItem()+"' AND position='AE'";
            pst = conn.prepareStatement(sql);
            pst.execute();
     
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        } 
    }
    public void updateForCalculus(){
        try{
            String sql = "UPDATE candidates_info SET vote_count='"+ CalculusVote +"' WHERE fullname='"+CalculusCombo.getSelectedItem()+"' AND position='Calculus'";
            pst = conn.prepareStatement(sql);
            pst.execute();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    public void updateForLA(){
    try{
            String sql = "UPDATE candidates_info SET vote_count='"+ LAVote +"' WHERE fullname='"+LACombo.getSelectedItem()+"' AND position='LA'";
            pst = conn.prepareStatement(sql);
            pst.execute();

        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }   
    }
    public void updateForDLC(){
        for(int x=0;x<updateDLCList.length;x++){
            try{
                String sql = "UPDATE candidates_info SET vote_count='"+updateDLCList[x]+"' WHERE fullname='"+DLCList.get(x)+"' AND position = 'DLC'";
                pst = conn.prepareStatement(sql);
                pst.execute();
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, e);
            }  
        }
        
     
    }
    public void selectCourse(){
        try{
            String sql = "SELECT vote_count FROM courses WHERE course='"+courseLbl.getText()+"'";
            pst = conn.prepareStatement(sql);
            rs = pst.executeQuery();
            if(rs.next()){
                courseVote = Integer.parseInt(rs.getString("vote_count")) + 1;
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    public void updateCourseVote(){
        try{
            String sql = "UPDATE courses SET vote_count='"+ courseVote +"' WHERE course='"+courseLbl.getText()+"'";
            pst = conn.prepareStatement(sql);
            pst.execute();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        voteCombo = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        DLCListTxt = new javax.swing.JList();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        exitBtn = new javax.swing.JButton();
        AECombo = new javax.swing.JComboBox();
        jLabel6 = new javax.swing.JLabel();
        CppCombo = new javax.swing.JComboBox();
        LACombo = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        JavaCombo = new javax.swing.JComboBox();
        DLCCombo = new javax.swing.JComboBox();
        CalculusCombo = new javax.swing.JComboBox();
        PhysicsCombo = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        addDLCBtn = new javax.swing.JButton();
        removeDLCBtn = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        nameLbl = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        courseLbl = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        ageLbl = new javax.swing.JLabel();
        statusLbl = new javax.swing.JLabel();
        genderLbl = new javax.swing.JLabel();
        yearLbl = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Please select your candidates", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 14), new java.awt.Color(102, 0, 0))); 

        voteCombo.setText("Vote");
        voteCombo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voteComboActionPerformed(evt);
            }
        });

      
        jScrollPane1.setViewportView(DLCListTxt);

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel2.setText("C++ Professors");

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel5.setText("Calculus Professors");

        exitBtn.setText("Exit");
        exitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBtnActionPerformed(evt);
            }
        });

        AECombo.setFont(new java.awt.Font("Calibri", 0, 14));
        AECombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-" }));

        jLabel6.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel6.setText("Linear Algebra Professors");

        CppCombo.setFont(new java.awt.Font("Calibri", 0, 14));
        CppCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-" }));

        LACombo.setFont(new java.awt.Font("Calibri", 0, 14)); 
        LACombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-" }));

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel4.setText("Academic English Professors");

        JavaCombo.setFont(new java.awt.Font("Calibri", 0, 14));
        JavaCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-" }));

        DLCCombo.setFont(new java.awt.Font("Calibri", 0, 14)); 
        DLCCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-" }));

        CalculusCombo.setFont(new java.awt.Font("Calibri", 0, 14));
        CalculusCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-" }));

        PhysicsCombo.setFont(new java.awt.Font("Calibri", 0, 14)); 
        PhysicsCombo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-" }));

        jLabel1.setFont(new java.awt.Font("Calibri", 0, 14)); 
        jLabel1.setText("Java Professors");

        jLabel3.setFont(new java.awt.Font("Calibri", 0, 14)); 
        jLabel3.setText("Physics Professors");

        addDLCBtn.setText("Add DLC Professors");
        addDLCBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDLCBtnActionPerformed(evt);
            }
        });

        removeDLCBtn.setText("Remove DLC Professors");
        removeDLCBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeDLCBtnActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Calibri", 0, 14)); 
        jLabel9.setForeground(new java.awt.Color(102, 0, 0));
        jLabel9.setText("Pick any DLC Professors in the list:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addGap(43, 43, 43)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(LACombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CalculusCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(AECombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(PhysicsCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(CppCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(JavaCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(66, 66, 66)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(43, 43, 43)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(addDLCBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(removeDLCBtn))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addComponent(voteCombo, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(exitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1)
                            .addComponent(DLCCombo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(jLabel9))
                .addContainerGap(267, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(JavaCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(DLCCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(CppCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(addDLCBtn)
                    .addComponent(removeDLCBtn))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(PhysicsCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(AECombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(CalculusCombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(LACombo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(voteCombo)
                    .addComponent(exitBtn))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jLabel8.setFont(new java.awt.Font("Calibri", 3, 18));
        jLabel8.setForeground(new java.awt.Color(102, 0, 0));
        jLabel8.setText("Please Vote Wisely!");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Students Info", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Calibri", 3, 14), new java.awt.Color(102, 0, 0)));

        jLabel14.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel14.setText("Year:");

        jLabel11.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel11.setText("Age:");

        nameLbl.setFont(new java.awt.Font("Calibri", 0, 14)); 
        nameLbl.setForeground(new java.awt.Color(102, 0, 0));
        nameLbl.setText("Name");

        jLabel15.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel15.setText("Status:");

        courseLbl.setFont(new java.awt.Font("Calibri", 0, 14));
        courseLbl.setForeground(new java.awt.Color(102, 0, 0));
        courseLbl.setText("Course");

        jLabel10.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel10.setText("Name:");

        ageLbl.setFont(new java.awt.Font("Calibri", 0, 14)); 
        ageLbl.setForeground(new java.awt.Color(102, 0, 0));
        ageLbl.setText("Age");

        statusLbl.setFont(new java.awt.Font("Calibri", 0, 14));
        statusLbl.setForeground(new java.awt.Color(102, 0, 0));
        statusLbl.setText("Status");

        genderLbl.setFont(new java.awt.Font("Calibri", 0, 14));
        genderLbl.setForeground(new java.awt.Color(102, 0, 0));
        genderLbl.setText("Gender");

        yearLbl.setFont(new java.awt.Font("Calibri", 0, 14)); 
        yearLbl.setForeground(new java.awt.Color(102, 0, 0));
        yearLbl.setText("Year");

        jLabel12.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel12.setText("Gender:");

        jLabel13.setFont(new java.awt.Font("Calibri", 0, 14));
        jLabel13.setText("Course:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(genderLbl)
                    .addComponent(ageLbl)
                    .addComponent(nameLbl))
                .addGap(249, 249, 249)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13)
                    .addComponent(jLabel14)
                    .addComponent(jLabel15))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(statusLbl)
                    .addComponent(yearLbl)
                    .addComponent(courseLbl))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(nameLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel11)
                            .addComponent(ageLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel12)
                            .addComponent(genderLbl)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel13)
                            .addComponent(courseLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(yearLbl))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(statusLbl))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(96, 96, 96)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51))
        );

        pack();
        setLocationRelativeTo(null);
    }

    private void exitBtnActionPerformed(java.awt.event.ActionEvent evt) {
        Login l = new Login();
        close();
        l.setVisible(true);
    }

    private void removeDLCBtnActionPerformed(java.awt.event.ActionEvent evt) {
        String s = selected;    
        try{
                if(index==-1){
                    JOptionPane.showMessageDialog(null, "Please select DLC Professor to remove");
                }else{
   
                	DLCList.remove(index);
                   dlm.removeElementAt(index);
                   DLCCombo.addItem(s);
                }
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
      }

    private void addDLCBtnActionPerformed(java.awt.event.ActionEvent evt) {
            int itemAdded =   DLCListTxt.getModel().getSize();
        
         if(DLCCombo.getSelectedItem().equals("-")){
                JOptionPane.showMessageDialog(null, "Please select DLC professor to add");
         }else{
                    if(itemAdded<5){
                           dlm.clear();
                           
                            int addedIndex = DLCCombo.getSelectedIndex();

                            DLCList.add(DLCCombo.getSelectedItem().toString());
                                
                   

                            for(int x=0;x<DLCList.size();x++){
                                dlm.addElement(DLCList.get(x));
                            }
                            DLCListTxt.setModel(dlm);
                           DLCCombo.removeItemAt(addedIndex);
                          
                            DLCCombo.setSelectedIndex(0);
                    }else{
                             JOptionPane.showMessageDialog(null, "Only 5 DLC professors are allowed!");
                    }
                  
         } 
                
    }

    private void voteComboActionPerformed(java.awt.event.ActionEvent evt) {
      
        if(JavaCombo.getSelectedIndex()==0 || CppCombo.getSelectedIndex()==0 || PhysicsCombo.getSelectedIndex()==0 || AECombo.getSelectedIndex()==0 || CalculusCombo.getSelectedIndex()==0 || LACombo.getSelectedIndex()==0 || DLCListTxt.getModel().getSize() == 0){
               JOptionPane.showMessageDialog(null, "Please fill up all the required fields");
           }else{
                int des = JOptionPane.showConfirmDialog(null, "Finished Voting?","Confirmation",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
                if(des==0){
                    selectVoteCountForJava();
               selectVoteCountForCpp();
               selectVoteCountForPhysics();
               selectVoteCountForAE();
               selectVoteCountForCalculus();
               selectVoteCountForLA();
               selectVoteCountForDLC();
               selectCourse();
               
                updateForJava();
                updateForCpp();
                updateForPhysics();
                updateForAE();
                updateForCalculus();
                updateForLA();
                updateForDLC();
                updateCourseVote();
                JOptionPane.showMessageDialog(null, "Voted Successfully!");
                }
               
           }
    }

    private void DLCListTxtValueChanged(javax.swing.event.ListSelectionEvent evt) {
 
          index = DLCListTxt.getSelectedIndex();
         selected=String.valueOf(DLCListTxt.getSelectedValue());
    }
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VoteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VoteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VoteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VoteForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
            java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VoteForm().setVisible(true);
            }
        });
    }

    
    private javax.swing.JButton addDLCBtn;
    public javax.swing.JLabel ageLbl;
    private javax.swing.JComboBox AECombo;
    private javax.swing.JComboBox LACombo;
    public javax.swing.JLabel courseLbl;
    private javax.swing.JButton exitBtn;
    public javax.swing.JLabel genderLbl;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    public javax.swing.JLabel nameLbl;
    private javax.swing.JComboBox JavaCombo;
    private javax.swing.JButton removeDLCBtn;
    private javax.swing.JComboBox PhysicsCombo;
    private javax.swing.JComboBox DLCCombo;
    private javax.swing.JList DLCListTxt;
    public javax.swing.JLabel statusLbl;
    private javax.swing.JComboBox CalculusCombo;
    private javax.swing.JComboBox CppCombo;
    private javax.swing.JButton voteCombo;
    public javax.swing.JLabel yearLbl;
}
